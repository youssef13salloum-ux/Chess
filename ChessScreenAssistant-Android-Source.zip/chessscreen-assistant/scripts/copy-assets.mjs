import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const publicDir = path.join(root, 'web', 'public');
const modelOut = path.join(publicDir, 'models');
const ortOut = path.join(publicDir, 'ort');
const engineOut = path.join(publicDir, 'engine');

for (const dir of [modelOut, ortOut, engineOut]) {
  fs.mkdirSync(dir, { recursive: true });
}

function copyRequired(from, to, label) {
  if (!fs.existsSync(from)) throw new Error(`Required ${label} not found: ${from}`);
  fs.copyFileSync(from, to);
}

copyRequired(
  path.join(root, 'node_modules', '@scoriiu', 'fenshot', 'model', 'chess-tiles-v2.onnx'),
  path.join(modelOut, 'chess-tiles-v2.onnx'),
  'Fenshot chess recognition model'
);

for (const filename of ['ort-wasm-simd-threaded.mjs', 'ort-wasm-simd-threaded.wasm']) {
  copyRequired(
    path.join(root, 'node_modules', 'onnxruntime-web', 'dist', filename),
    path.join(ortOut, filename),
    `ONNX Runtime asset ${filename}`
  );
}

function walk(dir) {
  const found = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) found.push(...walk(full));
    else found.push(full);
  }
  return found;
}

const stockfishRoot = path.join(root, 'node_modules', 'stockfish');
const files = walk(stockfishRoot);
const worker = files.find((file) => /stockfish.*lite-single\.js$/i.test(path.basename(file)));
if (!worker) throw new Error('Could not locate the Stockfish lite single-threaded worker in npm package.');
const wasmName = path.basename(worker).replace(/\.js$/i, '.wasm');
const wasm = files.find((file) => path.basename(file) === wasmName);
if (!wasm) throw new Error(`Could not locate matching Stockfish WebAssembly file: ${wasmName}`);

fs.copyFileSync(worker, path.join(engineOut, path.basename(worker)));
fs.copyFileSync(wasm, path.join(engineOut, wasmName));
fs.writeFileSync(path.join(engineOut, 'engine-name.txt'), path.basename(worker), 'utf8');
console.log(`Copied Stockfish worker ${path.basename(worker)} and its WASM file.`);
