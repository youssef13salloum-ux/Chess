# Third-party components

This project downloads/copies the following components during its build. Their original licenses and attribution files are distributed by their respective upstream packages and should be retained when redistributing the app:

- `@scoriiu/fenshot` — MIT license; see https://github.com/scoriiu/fenshot
- `stockfish` / Stockfish.js — GPL-3.0; see https://github.com/nmrugg/stockfish.js and the included upstream `Copying.txt` from the npm package. A distributable APK containing Stockfish must satisfy the applicable GPL source-code and notice requirements.
- `onnxruntime-web` — MIT license; see https://github.com/microsoft/onnxruntime
- `chess.js` — BSD-2-Clause; see https://github.com/jhlywa/chess.js
- AndroidX WebKit, Activity, Core — Apache License 2.0

The build script copies the Stockfish engine JavaScript and WebAssembly files; it does not intentionally alter them. This prototype archive does not contain prebuilt third-party binaries.
