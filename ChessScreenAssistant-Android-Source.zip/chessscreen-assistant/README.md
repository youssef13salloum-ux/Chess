# Chess Screen Assistant (Android, prototype 0.1)

A native Android prototype that requests the user's explicit screen-capture consent, looks for 2D chessboards in captured frames, tracks turns when it can infer them from successive positions, and runs Stockfish locally. Notifications are sent only after a reliable board read and an inferred turn matching the detected board perspective. Image frames, board recognition, and engine analysis are intended to stay on the device.

## Important status

- This archive is **source code**, not an installable APK.
- This environment does not have the Android SDK installed, so an APK could not be compiled or device-tested here.
- A GitHub Actions workflow is included to build a debug APK in the cloud once this project is in a GitHub repository. The `app-debug.apk` is then available as a workflow artifact.
- Automatic move-turn inference is best-effort. If the app starts in the middle of a game, it waits for a visible board change before confidently inferring whose turn it is. 3D boards and obscured/animated boards may not be recognized.
- Use this for training and analysis. Using live move assistance during rated/competitive online play may violate that site's rules.

## Features in the prototype

- Native Android screen capture using the official MediaProjection permission flow and a persistent foreground-service notification.
- Fenshot recognition model (`@scoriiu/fenshot`) for board detection, piece recognition, orientation detection and confidence rejection.
- Stockfish.js lite single-threaded engine running locally in a Web Worker.
- A notification showing a suggested move after a reliable position/turn inference.
- If no board is detected, or the read is uncertain, the app does not issue a move notification.
- The capture notification includes a Stopp action; the app also has a stop button.

## Build APK without installing Android Studio on your phone

The included workflow builds the APK on GitHub's hosted runner, but the source must first be uploaded to a GitHub repository. After that:

1. Open the repository's **Actions** tab.
2. Choose **Build Android APK**, then **Run workflow** (or push a commit to `main`).
3. Open the completed run and download the artifact named `chess-screen-assistant-debug-apk`.
4. Extract `app-debug.apk` on the Android device and install it. Android may ask permission to install from that download source; only continue for a build you trust.

The installed debug APK is unsigned for Play Store distribution but can be installed manually on a compatible Android device.

## Local developer build

Requires JDK 21, Android SDK Platform 35, Android build tools, Node.js 22, and Gradle 8+.

```bash
npm install
npm run build
mkdir -p app/src/main/assets
cp -R web/dist/. app/src/main/assets/
gradle assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Runtime behavior

- Tap **Scan starten** and accept Android's screen-capture dialog.
- For cross-app scanning, choose the whole-screen option where Android offers that choice.
- The Android capture notification stays visible while capture is active.
- The app derives whether the board is viewed from White's or Black's side from the screenshot's pawn orientation.
- The app compares successive positions to infer whose turn comes next. On a mid-game start it may wait for the next move rather than guessing.
- It evaluates moves locally with Stockfish. No API key is needed. The first start downloads nothing from a server; the models/engine are included in the build by the npm build script.

## Licenses

- App code in this prototype: MIT License (see `LICENSE`).
- `@scoriiu/fenshot`: MIT License. Its model is copied from the npm package at build time.
- Stockfish.js: GPL-3.0. Stockfish's license/source obligations apply to any redistributed build. See `THIRD_PARTY_NOTICES.md` and the Stockfish package's license for details.
- ONNX Runtime Web and chess.js are subject to their respective upstream licenses.
