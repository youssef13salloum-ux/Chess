package com.example.chessscreen

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import androidx.core.app.NotificationCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { launchCaptureConsent() }

    private val captureConsent = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            webView.evaluateJavascript("window.ChessScreen?.setCaptureState?.(true)", null)
        } else {
            webView.evaluateJavascript("window.ChessScreen?.setMessage?.('Bildschirmfreigabe wurde nicht erteilt.')", null)
        }
    }

    private val frameReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val b64 = intent?.getStringExtra(ScreenCaptureService.EXTRA_FRAME_B64) ?: return
            // JPEG base64 contains no quotes, backslashes, or JavaScript delimiters.
            webView.evaluateJavascript(
                "window.ChessScreen?.onFrame?.('data:image/jpeg;base64,$b64')",
                null
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannels()
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(12, 17, 24))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mediaPlaybackRequiresUserGesture = true
            addJavascriptInterface(ChessBridge(this@MainActivity), "ChessBridge")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                    assetLoader.shouldInterceptRequest(request.url)
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        val filter = IntentFilter(ScreenCaptureService.ACTION_FRAME)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(frameReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(frameReceiver, filter)
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(frameReceiver) } catch (_: Exception) {}
        webView.removeJavascriptInterface("ChessBridge")
        webView.destroy()
        super.onDestroy()
    }

    private fun requestCapture() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchCaptureConsent()
        }
    }

    private fun launchCaptureConsent() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        captureConsent.launch(manager.createScreenCaptureIntent())
    }

    private fun createNotificationChannels() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(
            ScreenCaptureService.CAPTURE_CHANNEL_ID,
            "Bildschirmerkennung",
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Zeigt an, wenn die Bildschirm-Erkennung aktiv ist." })
        manager.createNotificationChannel(NotificationChannel(
            MOVE_CHANNEL_ID,
            "Schachzug-Hinweise",
            NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "Hinweise für erkannte Schachstellungen." })
    }

    inner class ChessBridge(private val activity: MainActivity) {
        @JavascriptInterface
        fun startCapture() = activity.runOnUiThread { requestCapture() }

        @JavascriptInterface
        fun stopCapture() = activity.runOnUiThread {
            startService(Intent(activity, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))
            webView.evaluateJavascript("window.ChessScreen?.setCaptureState?.(false)", null)
        }

        @JavascriptInterface
        fun notifyBestMove(san: String, uci: String, color: String) {
            val safeSan = san.take(40)
            val safeUci = uci.take(10)
            val safeColor = if (color == "black") "Schwarz" else "Weiß"
            val manager = getSystemService(NotificationManager::class.java)
            val notification = NotificationCompat.Builder(activity, MOVE_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle("Bester Zug · $safeColor")
                .setContentText("$safeSan  ($safeUci)")
                .setStyle(NotificationCompat.BigTextStyle().bigText("Vorgeschlagener Zug: $safeSan ($safeUci). Nur als Analysehinweis verwenden."))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()
            manager.notify(MOVE_NOTIFICATION_ID, notification)
        }

        @JavascriptInterface
        fun setEngineStatus(status: String) {
            activity.runOnUiThread {
                webView.evaluateJavascript(
                    "window.ChessScreen?.setNativeStatus?.(${JSONObject.quote(status.take(120))})",
                    null
                )
            }
        }
    }

    companion object {
        const val MOVE_CHANNEL_ID = "chess_moves"
        const val MOVE_NOTIFICATION_ID = 5201
    }
}
