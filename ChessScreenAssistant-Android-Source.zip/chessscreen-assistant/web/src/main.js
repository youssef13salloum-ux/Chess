import './style.css';
import { Chess } from 'chess.js';
import { createRecognizer, resolveOrientation, placementToFen } from '@scoriiu/fenshot';

const el = (id) => document.getElementById(id);
const startBtn = el('startBtn');
const stopBtn = el('stopBtn');
const statusTitle = el('statusTitle');
const statusText = el('statusText');
const statusIcon = el('statusIcon');
const pillText = el('pillText');
const livePill = document.querySelector('.live-pill');
const engineBadge = el('engineBadge');
const colorChip = el('colorChip');
const moveSan = el('moveSan');
const moveUci = el('moveUci');
const positionInfo = el('positionInfo');

let scanning = false;
let recognizer = null;
let frameBusy = false;
let missedBoardFrames = 0;
let previousPlacement = null;
let sideToMove = null;
let playerColor = null;
let lastPositionRequested = '';
let latestAnalysisKey = '';
let engineWorker = null;
let engineReady = false;
let engineStartPromise = null;
let resolveEngineReady = null;
let engineLineHandler = null;
let engineRequestSequence = 0;
let activeAnalysis = null;
let lastResultKey = '';
const START_POSITION = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR';

function setStatus(title, detail, icon = '◌') {
  statusTitle.textContent = title;
  statusText.textContent = detail;
  statusIcon.textContent = icon;
}

function setCaptureState(active) {
  scanning = Boolean(active);
  startBtn.disabled = scanning;
  stopBtn.disabled = !scanning;
  pillText.textContent = scanning ? 'Scan aktiv' : 'Bereit';
  livePill.classList.toggle('active', scanning);
  if (scanning) setStatus('Suche nach einem Schachbrett', 'Es werden nur sichere, zuverlässig erkannte Stellungen analysiert. Ohne Brett kein Zug-Hinweis.', '⌕');
  else setStatus('Scanner gestoppt', 'Tippe auf „Scan starten“, wenn du erneut eine Stellung erkennen möchtest.', 'Ⅱ');
}

function setMessage(message) {
  setStatus('Scanner nicht gestartet', message || 'Keine Bildschirmfreigabe.', '!');
}

function setNativeStatus(status) {
  engineBadge.textContent = status;
}

window.ChessScreen = {
  setCaptureState,
  setMessage,
  setNativeStatus,
  onFrame: (dataUrl) => { void processFrame(dataUrl); },
};

startBtn.addEventListener('click', async () => {
  setStatus('Engine wird vorbereitet', 'Der lokale Erkenner und Stockfish werden geladen …', '↻');
  startBtn.disabled = true;
  try {
    await prepareRecognizer();
    await ensureEngine();
    engineBadge.textContent = 'Stockfish bereit';
    setStatus('Android-Freigabe nötig', 'Bestätige im Android-Dialog die Bildschirmaufnahme. Wähle den gesamten Bildschirm, wenn du zwischen Apps wechseln möchtest.', '▣');
    if (window.ChessBridge?.startCapture) window.ChessBridge.startCapture();
    else setStatus('Vorschau-Modus', 'Die native Android-Bildschirmaufnahme ist nur in der APK verfügbar.', '!');
  } catch (error) {
    startBtn.disabled = false;
    engineBadge.textContent = 'Engine konnte nicht laden';
    setStatus('Laden fehlgeschlagen', String(error?.message || error), '!');
  }
});

stopBtn.addEventListener('click', () => {
  if (window.ChessBridge?.stopCapture) window.ChessBridge.stopCapture();
  setCaptureState(false);
});

async function prepareRecognizer() {
  if (recognizer) return recognizer;
  recognizer = createRecognizer({
    modelUrl: new URL('./models/chess-tiles-v2.onnx', window.location.href).toString(),
    wasmPaths: new URL('./ort/', window.location.href).toString(),
  });
  if (typeof recognizer.warmUp === 'function') recognizer.warmUp();
  return recognizer;
}

async function ensureEngine() {
  if (engineReady) return;
  if (engineStartPromise) return engineStartPromise;
  engineStartPromise = new Promise(async (resolve, reject) => {
    try {
      const response = await fetch(new URL('./engine/engine-name.txt', window.location.href));
      if (!response.ok) throw new Error('Stockfish-Datei fehlt im Paket.');
      const workerName = (await response.text()).trim();
      if (!workerName) throw new Error('Stockfish-Worker ist leer.');
      engineWorker = new Worker(new URL(`./engine/${workerName}`, window.location.href));
      const timeout = setTimeout(() => reject(new Error('Stockfish reagiert nicht rechtzeitig.')), 25000);
      engineLineHandler = (event) => {
        const line = String(event.data ?? '').trim();
        if (line === 'uciok') engineWorker.postMessage('isready');
        if (line === 'readyok' && !engineReady) {
          engineReady = true;
          clearTimeout(timeout);
          resolve();
        }
        if (line.startsWith('info depth')) {
          const depth = line.match(/\bdepth\s+(\d+)/)?.[1];
          if (depth) engineBadge.textContent = `Stockfish · Tiefe ${depth}`;
        }
        if (line.startsWith('bestmove ')) handleBestMove(line);
      };
      engineWorker.addEventListener('message', engineLineHandler);
      engineWorker.addEventListener('error', () => {
        clearTimeout(timeout);
        reject(new Error('Stockfish konnte nicht gestartet werden.'));
      }, { once: true });
      engineWorker.postMessage('uci');
    } catch (error) {
      reject(error);
    }
  });
  return engineStartPromise;
}

async function processFrame(dataUrl) {
  if (!scanning || !recognizer || frameBusy) return;
  frameBusy = true;
  try {
    const img = new Image();
    img.src = dataUrl;
    await img.decode();
    const result = await recognizer.recognize(img);
    if (!result || !result.reliable) {
      missedBoardFrames++;
      if (missedBoardFrames >= 5) {
        // Do not produce an answer on empty/uncertain frames. Reset tracking after leaving the board for a while.
        previousPlacement = null;
        sideToMove = null;
        lastPositionRequested = '';
      }
      return;
    }

    missedBoardFrames = 0;
    const resolved = resolveOrientation(result.placement);
    const placement = resolved.placement;
    const orientation = String(resolved.orientation || 'white').toLowerCase();
    playerColor = orientation.includes('black') ? 'b' : 'w';
    colorChip.textContent = playerColor === 'b' ? 'Du spielst Schwarz' : 'Du spielst Weiß';
    setStatus('Schachbrett erkannt', `Perspektive erkannt: ${playerColor === 'b' ? 'Schwarz' : 'Weiß'}. Stellungssicherheit ${Math.round((result.meanConfidence || 0) * 100)} %.`, '✓');

    if (previousPlacement === null) {
      previousPlacement = placement;
      if (placement === START_POSITION) sideToMove = 'w';
      if (sideToMove === playerColor) queueAnalysis(placement, sideToMove);
      return;
    }

    if (placement === previousPlacement) {
      if (sideToMove === playerColor) queueAnalysis(placement, sideToMove);
      return;
    }

    const inferredTurn = inferNextTurn(previousPlacement, placement, sideToMove);
    previousPlacement = placement;
    sideToMove = inferredTurn;
    lastPositionRequested = '';

    if (sideToMove === playerColor) {
      queueAnalysis(placement, sideToMove);
    } else {
      setStatus('Zug erkannt', 'Warte auf deinen Zug. Es wird keine Empfehlung gesendet, solange der erkannte Zug dem Gegner gehört oder unklar ist.', '↻');
    }
  } catch (error) {
    // Recognition errors and non-board frames are intentionally silent with respect to notifications.
    console.debug('Frame skipped:', error);
  } finally {
    frameBusy = false;
  }
}

function inferNextTurn(beforePlacement, afterPlacement, knownTurn) {
  const candidates = knownTurn ? [knownTurn] : ['w', 'b'];
  for (const candidateTurn of candidates) {
    try {
      const startFen = placementToFen(beforePlacement, candidateTurn);
      const current = new Chess(startFen);
      for (const move of current.moves({ verbose: true })) {
        const trial = new Chess(startFen);
        trial.move({ from: move.from, to: move.to, promotion: move.promotion });
        if (trial.fen().split(' ')[0] === afterPlacement) return trial.turn();
      }
    } catch (_) { /* Try the next possible side to move. */ }
  }

  // Fallback for a missed frame/special move: the destination square usually reveals the color that moved.
  const before = fenPlacementToSquares(beforePlacement);
  const after = fenPlacementToSquares(afterPlacement);
  const colorsOnChangedSquares = new Set();
  for (let i = 0; i < 64; i++) {
    if (before[i] !== after[i] && after[i]) colorsOnChangedSquares.add(after[i] === after[i].toUpperCase() ? 'w' : 'b');
  }
  if (colorsOnChangedSquares.size === 1) return [...colorsOnChangedSquares][0] === 'w' ? 'b' : 'w';
  return null;
}

function fenPlacementToSquares(placement) {
  const squares = [];
  for (const row of placement.split('/')) {
    for (const c of row) {
      if (/\d/.test(c)) for (let n = Number(c); n > 0; n--) squares.push('');
      else squares.push(c);
    }
  }
  return squares.length === 64 ? squares : Array(64).fill('');
}

function queueAnalysis(placement, turn) {
  if (!turn || turn !== playerColor || !engineReady) return;
  const fen = placementToFen(placement, turn);
  const requestKey = `${placement}|${turn}`;
  if (requestKey === lastPositionRequested || requestKey === lastResultKey) return;
  lastPositionRequested = requestKey;
  latestAnalysisKey = requestKey;
  activeAnalysis = { key: requestKey, fen, turn, color: playerColor };
  engineWorker.postMessage('stop');
  engineWorker.postMessage('ucinewgame');
  engineWorker.postMessage(`position fen ${fen}`);
  engineWorker.postMessage('go movetime 1800');
  setStatus('Stellung wird analysiert', 'Stockfish durchsucht legale Züge auf dem Gerät …', '↻');
}

function handleBestMove(line) {
  const match = line.match(/^bestmove\s+([a-h][1-8][a-h][1-8][qrbn]?)/);
  if (!match || !activeAnalysis) return;
  const move = match[1];
  const analysis = activeAnalysis;
  if (analysis.key !== latestAnalysisKey || analysis.key !== lastPositionRequested) return;
  lastResultKey = analysis.key;
  let san = move;
  try {
    const game = new Chess(analysis.fen);
    const moveObject = { from: move.slice(0, 2), to: move.slice(2, 4) };
    if (move.length > 4) moveObject.promotion = move[4];
    san = game.move(moveObject)?.san || move;
  } catch (_) { /* UCI move remains a useful fallback. */ }

  moveSan.textContent = san;
  moveUci.textContent = `${move.slice(0, 2)} → ${move.slice(2, 4)}${move.length > 4 ? ` = ${move[4].toUpperCase()}` : ''}`;
  positionInfo.textContent = `Erkannte Perspektive: ${analysis.color === 'b' ? 'Schwarz' : 'Weiß'} · Empfehlung nur nach zuverlässiger Brett-Erkennung.`;
  setStatus('Bester Zug berechnet', `Stockfish schlägt ${san} vor.`, '✓');
  if (window.ChessBridge?.notifyBestMove) {
    window.ChessBridge.notifyBestMove(san, move, analysis.color === 'b' ? 'black' : 'white');
  }
}

window.addEventListener('pagehide', () => {
  try { engineWorker?.terminate(); } catch (_) {}
});
